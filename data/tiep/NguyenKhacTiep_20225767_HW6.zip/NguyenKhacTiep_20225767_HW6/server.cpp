#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <map>
#include <thread>
#include <mutex>
#include <unistd.h>
#include <arpa/inet.h>
using namespace std;

#define PORT 1010
#define BUFFER_SIZE 1024

mutex log_mutex;                     // Bảo vệ khi ghi file log
map<int, string> client_names;       // Lưu tên đăng nhập theo socket

// Hàm xử lý từng client
void handle_client(int client_sock, sockaddr_in client_addr) {
    char buffer[BUFFER_SIZE];
    string client_ip = inet_ntoa(client_addr.sin_addr);
    int client_port = ntohs(client_addr.sin_port);

    // Nhận login name từ client
    int bytes_received = recv(client_sock, buffer, BUFFER_SIZE - 1, 0);
    if (bytes_received <= 0) {
        close(client_sock);
        return;
    }
    buffer[bytes_received] = '\0';
    string login_name = buffer;

    {
        lock_guard<mutex> lock(log_mutex);
        client_names[client_sock] = login_name;
    }

    string welcome = "Hello " + login_name + "!";
    send(client_sock, welcome.c_str(), welcome.size(), 0);

    cout << login_name << " connected from "
         << client_ip << ":" << client_port << endl;
    while (true) {
        bytes_received = recv(client_sock, buffer, BUFFER_SIZE - 1, 0);
        if (bytes_received <= 0) {
            cout << login_name << " disconnected." << endl;
            close(client_sock);
            break;
        }
        buffer[bytes_received] = '\0';
        string message = buffer;

        // Ghi log vào file tương ứng với login name
        {
            lock_guard<mutex> lock(log_mutex);
            ofstream log_file(login_name + ".log", ios::app);
            log_file << "[" << client_ip << ":" << client_port << "] "
                     << message << endl;
        }

        cout << "[LOG] " << login_name << ": " << message << endl;
    }
}

int main() {
    int server_sock;
    sockaddr_in server_addr{}, client_addr{};
    socklen_t client_len = sizeof(client_addr);
    server_sock = socket(AF_INET, SOCK_STREAM, 0);
    if (server_sock < 0) {
        perror("Socket creation failed");
        return 1;
    }

    int opt = 1;
    setsockopt(server_sock, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    if (::bind(server_sock, (sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("Bind failed");
        close(server_sock);
        return 1;
    }

    if (listen(server_sock, 5) < 0) {
        perror("Listen failed");
        close(server_sock);
        return 1;
    }

    cout << "Listening on port " << PORT << "..." << endl;

    // Chấp nhận nhiều client
    while (true) {
        int client_sock = accept(server_sock, (sockaddr*)&client_addr, &client_len);
        if (client_sock < 0) {
            perror("Accept failed");
            continue;
        }
        // Tạo luồng riêng để xử lý client
        thread(handle_client, client_sock, client_addr).detach();
    }

    close(server_sock);
    return 0;
}
