#include <iostream>
#include <string>
#include <cstring>
#include <unistd.h>
#include <arpa/inet.h>

using namespace std;

#define SERVER_IP "127.0.0.1"
#define SERVER_PORT 1010
#define BUFFER_SIZE 1024

int main() {
    int sock;
    sockaddr_in server_addr{};
    char buffer[BUFFER_SIZE];
    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        perror("Socket creation failed");
        return 1;
    }
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(SERVER_PORT);
    inet_pton(AF_INET, SERVER_IP, &server_addr.sin_addr);

    // Kết nối đến server
    if (connect(sock, (sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("Connection failed");
        return 1;
    }

    // Gửi login name
    cout << "Enter your login name: ";
    string login_name;
    getline(cin, login_name);
    send(sock, login_name.c_str(), login_name.size(), 0);

    // Nhận phản hồi từ server
    int bytes_received = recv(sock, buffer, BUFFER_SIZE - 1, 0);
    if (bytes_received > 0) {
        buffer[bytes_received] = '\0';
        cout << buffer << endl;
    }

    cout << "You can now send messages. Type 'exit' to quit." << endl;

    // Gửi tin nhắn
    while (true) {
        string msg;
        getline(cin, msg);
        if (msg == "exit") break;

        send(sock, msg.c_str(), msg.size(), 0);
    }

    close(sock);
    return 0;
}
