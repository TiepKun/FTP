# NguyenKhacTiep_20225767_HW1
Bài tập tuần 1 - Thực hành lập trình mạng
