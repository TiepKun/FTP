#include <iostream>
#include <string>
#include <sstream>
#include <cstring>
#include <cstdlib>
#include <cerrno>

#include <csignal>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <arpa/inet.h>

using namespace std;

static void set_socket_timeouts(int fd, int rcv_sec, int snd_sec) {
    timeval tv;

    tv.tv_sec = rcv_sec;
    tv.tv_usec = 0;
    if (setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv)) < 0) {
        perror("setsockopt SO_RCVTIMEO");
    }

    tv.tv_sec = snd_sec;
    tv.tv_usec = 0;
    if (setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv)) < 0) {
        perror("setsockopt SO_SNDTIMEO");
    }
}

typedef void Sigfunc(int);
static void connect_alarm(int) { /* empty */ }

static int connect_timeo(int sockfd, const sockaddr *saptr, socklen_t salen, int nsec) {
    Sigfunc *old = signal(SIGALRM, connect_alarm);
    alarm((unsigned)nsec);

    int n = connect(sockfd, saptr, salen);
    if (n < 0) {
        if (errno == EINTR) errno = ETIMEDOUT;
    }

    alarm(0);
    signal(SIGALRM, old);
    return n;
}

static bool sendLine(int sock, const string &s) {
    string data = s + "\n";
    const char *p = data.c_str();
    size_t left = data.size();

    while (left > 0) {
        ssize_t n = send(sock, p, left, 0);
        if (n > 0) {
            left -= (size_t)n;
            p += n;
            continue;
        }
        if (n < 0 && errno == EINTR) continue;
        // timeout: errno = EAGAIN/EWOULDBLOCK (khi dùng SO_SNDTIMEO)
        return false;
    }
    return true;
}

static bool recvLine(int sock, string &out) {
    out.clear();
    char c;

    while (true) {
        ssize_t n = recv(sock, &c, 1, 0);
        if (n == 1) {
            if (c == '\r') continue;
            if (c == '\n') break;
            out.push_back(c);
            continue;
        }
        if (n == 0) return false; // server closed
        if (errno == EINTR) continue;
        // timeout: errno = EAGAIN/EWOULDBLOCK (khi dùng SO_RCVTIMEO)
        return false;
    }
    return true;
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        cerr << "Usage: " << argv[0] << " <ServerIP> <PortNumber>\n";
        return 1;
    }

    const char *serverIp = argv[1];
    int port = atoi(argv[2]);
    if (port <= 0) {
        cerr << "Invalid port\n";
        return 1;
    }

    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        perror("socket");
        return 1;
    }

    sockaddr_in servAddr;
    memset(&servAddr, 0, sizeof(servAddr));
    servAddr.sin_family = AF_INET;
    servAddr.sin_port = htons(port);

    if (inet_pton(AF_INET, serverIp, &servAddr.sin_addr) <= 0) {
        cerr << "Invalid address\n";
        close(sock);
        return 1;
    }

    // connect timeout (tránh treo khi server unreachable)
    if (connect_timeo(sock, (sockaddr *)&servAddr, sizeof(servAddr), 5) < 0) {
        if (errno == ETIMEDOUT) {
            cerr << "Connect timeout (5s).\n";
        } else {
            perror("connect");
        }
        close(sock);
        return 1;
    }

    // recv/send timeout cho I/O
    set_socket_timeouts(sock, 10, 10);

    cout << "Connected to " << serverIp << ":" << port << "\n";

    // đọc thông điệp chào nếu có
    string line;
    errno = 0;
    if (recvLine(sock, line)) {
        cout << line << "\n";
    } else if (errno == EAGAIN || errno == EWOULDBLOCK) {
        cout << "(No welcome message: timeout)\n";
    }

    while (true) {
        cout << ">> ";
        cout.flush();

        string cmd;
        if (!getline(cin, cmd)) break; // EOF
        if (cmd.empty()) continue;

        errno = 0;
        if (!sendLine(sock, cmd)) {
            if (errno == EAGAIN || errno == EWOULDBLOCK) {
                cout << "Send timeout.\n";
            } else {
                cout << "Connection closed by server.\n";
            }
            break;
        }

        string resp;
        errno = 0;
        if (!recvLine(sock, resp)) {
            if (errno == EAGAIN || errno == EWOULDBLOCK) {
                cout << "Receive timeout.\n";
            } else {
                cout << "Connection closed by server.\n";
            }
            break;
        }

        cout << resp << "\n";
        if (resp.rfind("OK Bye", 0) == 0) break;
    }

    close(sock);
    return 0;
}
