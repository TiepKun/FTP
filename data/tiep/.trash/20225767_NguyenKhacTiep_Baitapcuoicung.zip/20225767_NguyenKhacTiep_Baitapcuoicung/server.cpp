#include <iostream>
#include <string>
#include <sstream>
#include <vector>
#include <map>
#include <fstream>
#include <ctime>
#include <csignal>
#include <cstring>
#include <cstdlib>
#include <cctype>
#include <cerrno>

#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <netinet/in.h>
#include <arpa/inet.h>

using namespace std;

static void set_socket_timeouts(int fd, int rcv_sec, int snd_sec) {
    timeval tv;

    tv.tv_sec = rcv_sec;
    tv.tv_usec = 0;
    if (setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv)) < 0) {
        perror("setsockopt SO_RCVTIMEO");
    }

    tv.tv_sec = snd_sec;
    tv.tv_usec = 0;
    if (setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv)) < 0) {
        perror("setsockopt SO_SNDTIMEO");
    }
}

struct Account {
    string user;
    string pass;
    int status;
};

vector<Account> loadAccounts() {
    vector<Account> accs;
    ifstream fin("account.txt");
    if (!fin) {
        cerr << "Cannot open account.txt\n";
        return accs;
    }
    Account a;
    while (fin >> a.user >> a.pass >> a.status) {
        accs.push_back(a);
    }
    return accs;
}

bool saveAccounts(const vector<Account> &accs) {
    ofstream fout("account.txt");
    if (!fout) {
        cerr << "Cannot write account.txt\n";
        return false;
    }
    for (auto &a : accs) {
        fout << a.user << " " << a.pass << " " << a.status << "\n";
    }
    return true;
}

string currentDateTime() {
    time_t now = time(nullptr);
    tm *ltm = localtime(&now);
    char buf[64];
    strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", ltm);
    return string(buf);
}

void writeLog(const string &line) {
    ofstream fout("auth.log", ios::app);
    if (!fout) {
        cerr << "Cannot open auth.log\n";
        return;
    }
    fout << "[" << currentDateTime() << "] " << line << "\n";
}

bool sendLine(int sock, const string &s) {
    string data = s + "\n";
    const char *p = data.c_str();
    size_t left = data.size();

    while (left > 0) {
        ssize_t n = send(sock, p, left, 0);
        if (n > 0) {
            left -= (size_t)n;
            p += n;
            continue;
        }
        if (n < 0 && errno == EINTR) continue;
        // timeout: errno = EAGAIN/EWOULDBLOCK (khi dùng SO_SNDTIMEO)
        return false;
    }
    return true;
}

bool recvLine(int sock, string &out) {
    out.clear();
    char c;

    while (true) {
        ssize_t n = recv(sock, &c, 1, 0);
        if (n == 1) {
            if (c == '\r') continue;
            if (c == '\n') break;
            out.push_back(c);
            continue;
        }
        if (n == 0) {
            // peer closed
            return false;
        }
        // n < 0
        if (errno == EINTR) continue;
        // timeout: errno = EAGAIN/EWOULDBLOCK (khi dùng SO_RCVTIMEO)
        return false;
    }

    return true;
}

string handleWho() {
    ifstream fin("auth.log");
    map<string, bool> online;
    string line;

    if (!fin) {
        return "LIST (no users online)";
    }

    while (getline(fin, line)) {
        if (line.empty()) continue;

        // log format: [YYYY-MM-DD HH:MM:SS] ACTION ...
        string dateTok, timeTok, action;
        stringstream ss(line);
        ss >> dateTok >> timeTok >> action;
        if (action.empty()) continue;

        if (action == "LOGIN") {
            string user;
            ss >> user;
            string fromTok, addrTok, resultTok;
            ss >> fromTok >> addrTok >> resultTok;
            if (resultTok == "SUCCESS") online[user] = true;
        } else if (action == "LOGOUT") {
            string user;
            ss >> user;
            online[user] = false;
        } else if (action == "ACCOUNT_LOCKED") {
            string user;
            ss >> user;
            online[user] = false;
        }
    }

    string result = "LIST";
    bool any = false;
    for (auto &p : online) {
        if (p.second) {
            result += " " + p.first;
            any = true;
        }
    }
    if (!any) {
        result += " (no users online)";
    }
    return result;
}

void handleClient(int clientSock, sockaddr_in clientAddr) {
    const int RCV_TIMEOUT_SEC = 10; // idle read timeout
    const int SND_TIMEOUT_SEC = 10; // write timeout
    set_socket_timeouts(clientSock, RCV_TIMEOUT_SEC, SND_TIMEOUT_SEC);

    string clientIp = inet_ntoa(clientAddr.sin_addr);
    int clientPort = ntohs(clientAddr.sin_port);

    bool loggedIn = false;
    string currentUser;
    string lastUserTried;
    int failCount = 0; //Số lần đăng nhập sai

    if (!sendLine(clientSock, "OK Welcome to TCP Auth Server. Type HELP for commands.")) {
        close(clientSock);
        return;
    }

    string line;
    while (true) {
        errno = 0;
        if (!recvLine(clientSock, line)) {
            if (errno == EAGAIN || errno == EWOULDBLOCK) {
                string who = loggedIn ? currentUser : "anonymous";
                writeLog("TIMEOUT " + who + " from " + clientIp + ":" + to_string(clientPort));
                (void)sendLine(clientSock, "ERR Timeout");
            }
            if (loggedIn) {
                writeLog("LOGOUT " + currentUser + " from " + clientIp + ":" + to_string(clientPort));
            }
            break;
        }

        if (line.empty()) continue;

        stringstream ss(line);
        string cmd;
        ss >> cmd;
        for (auto &ch : cmd) ch = (char)toupper((unsigned char)ch); //Chữ in hoa cho commands

        if (cmd == "HELP") {
            string msg = "OK Commands: LOGIN <user> <pass>, LOGOUT, WHO, HELP, QUIT";
            if (!sendLine(clientSock, msg)) break;
        }
        else if (cmd == "LOGIN") {
            string user, pass;
            ss >> user >> pass;
            if (user.empty() || pass.empty()) {
                sendLine(clientSock, "ERR Usage: LOGIN <user> <pass>");
                continue;
            }
            if (loggedIn) {
                sendLine(clientSock, "ERR Already logged in");
                continue;
            }

            vector<Account> accs = loadAccounts();
            int idx = -1;
            for (int i = 0; i < (int)accs.size(); ++i) {
                if (accs[i].user == user) {
                    idx = i;
                    break;
                }
            }

            if (idx == -1) {
                writeLog("LOGIN " + user + " from " + clientIp + ":" + to_string(clientPort) + " FAIL (user not found)");
                sendLine(clientSock, "ERR User not found");
                continue;
            }
            if (accs[idx].status == 0) {
                writeLog("LOGIN " + user + " from " + clientIp + ":" + to_string(clientPort) + " FAIL (account locked)");
                sendLine(clientSock, "ERR Account locked");
                continue;
            }
            if (accs[idx].pass != pass) {
                if (lastUserTried == user) {
                    failCount++;
                } else {
                    lastUserTried = user;
                    failCount = 1;
                }

                writeLog("LOGIN " + user + " from " + clientIp + ":" + to_string(clientPort) + " FAIL (wrong password)");

                if (failCount >= 3) { //Điều kiện khóa tài khoản (đăng nhập sai quá 3 lần)
                    accs[idx].status = 0;
                    saveAccounts(accs);
                    writeLog("ACCOUNT_LOCKED " + user);
                    sendLine(clientSock, "ERR Account locked due to too many failed attempts");
                } else {
                    sendLine(clientSock, "ERR Wrong password");
                }
                continue;
            }

            loggedIn = true;
            currentUser = user;
            lastUserTried = user;
            failCount = 0;

            writeLog("LOGIN " + user + " from " + clientIp + ":" + to_string(clientPort) + " SUCCESS");
            sendLine(clientSock, "OK Login successful");
        }
        else if (cmd == "LOGOUT") {
            if (!loggedIn) {
                sendLine(clientSock, "ERR Not logged in");
                continue;
            }
            writeLog("LOGOUT " + currentUser + " from " + clientIp + ":" + to_string(clientPort));
            loggedIn = false;
            currentUser.clear();
            sendLine(clientSock, "OK Logged out");
        }
        else if (cmd == "WHO") {
            string resp = handleWho();
            if (!sendLine(clientSock, resp)) break;
        }
        else if (cmd == "QUIT") {
            if (loggedIn) {
                writeLog("LOGOUT " + currentUser + " from " + clientIp + ":" + to_string(clientPort));
            }
            sendLine(clientSock, "OK Bye");
            break;
        }
        else {
            sendLine(clientSock, "ERR Unknown command");
        }
    }

    close(clientSock);
}

void sigchld_handler(int) {
    while (waitpid(-1, nullptr, WNOHANG) > 0) {}
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        cerr << "Usage: " << argv[0] << " <PortNumber>\n";
        return 1;
    }

    int port = atoi(argv[1]);
    if (port <= 0) {
        cerr << "Invalid port\n";
        return 1;
    }

    signal(SIGCHLD, sigchld_handler); //tránh zombie

    int listenSock = socket(AF_INET, SOCK_STREAM, 0);
    if (listenSock < 0) {
        perror("socket");
        return 1;
    }

    int opt = 1;
    if (setsockopt(listenSock, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0) {
        perror("setsockopt");
    }

    sockaddr_in servAddr;
    memset(&servAddr, 0, sizeof(servAddr));
    servAddr.sin_family = AF_INET;
    servAddr.sin_addr.s_addr = INADDR_ANY;
    servAddr.sin_port = htons(port);

    if (::bind(listenSock, (sockaddr *)&servAddr, sizeof(servAddr)) < 0) {
        perror("bind");
        close(listenSock);
        return 1;
    }

    if (listen(listenSock, 5) < 0) {
        perror("listen");
        close(listenSock);
        return 1;
    }

    cout << "Server listening on port " << port << "...\n";

    while (true) {
        sockaddr_in clientAddr;
        socklen_t clientLen = sizeof(clientAddr);
        int clientSock = accept(listenSock, (sockaddr *)&clientAddr, &clientLen);
        if (clientSock < 0) {
            perror("accept");
            continue;
        }

        pid_t pid = fork();
        if (pid < 0) {
            perror("fork");
            close(clientSock);
            continue;
        }
        if (pid == 0) {
            close(listenSock);
            handleClient(clientSock, clientAddr);
            exit(0);
        } else {
            close(clientSock);
        }
    }

    close(listenSock);
    return 0;
}
